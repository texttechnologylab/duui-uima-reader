The DT-Neg dataset can be freely used and re-distributed for research purposes provided it is properly citated.
The dataset is available for download from http://deeptutor.org/ (under Resources menu).
Whenever you use this dataset, please cite:

DT-Neg : Banjade, Rajendra & Rus, Vasile (2016). Tutorial Dialogues Annotated for Negation Scope and Focus. LREC


About the format of the dataset: Please see it in the annotation guideline available along with the dataset.

We are putting our effort to improve and increase the size of the dataset. 
For any comments and suggestions about this dataset, please write to Rajendra Banjade at rbanjade@memphis.edu. 

Thank you!	
---------------------------------	
Rajendra Banjade, and Vasile Rus
Sept, 2015